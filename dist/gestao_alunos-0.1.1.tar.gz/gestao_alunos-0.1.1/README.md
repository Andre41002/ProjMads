# Gestão de Alunos

Sistema de gestão de alunos, docentes, turmas e disciplinas desenvolvido pelo **Grupo 2 MADS 2ano**.
📦 Available on PyPI
